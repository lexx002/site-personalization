from django.db import models


class Player(models.Model):
    pass


class Game(models.Model):
    pass


class PlayerGameInfo(models.Model):
    pass
