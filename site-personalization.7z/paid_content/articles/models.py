from django.contrib.auth.models import User
from django.db import models


class Profile(models.Model):
    pass


class Article(models.Model):
    pass
